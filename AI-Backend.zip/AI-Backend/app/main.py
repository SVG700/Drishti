"""FastAPI application entrypoint for SIH26103 PAIMANA AI Backend."""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .services.data_loader import data_loader
from .api import health, projects, analytics, future_ai

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("paimana_backend")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown procedures."""
    logger.info("Starting SIH26103 PAIMANA AI Backend...")
    success, msg = data_loader.load_and_validate()
    if success:
        logger.info("PAIMANA dataset initialized: %s", msg)
    else:
        logger.warning("PAIMANA dataset warning: %s", msg)
    yield
    logger.info("Shutting down SIH26103 PAIMANA AI Backend.")


app = FastAPI(
    title="SIH26103 PAIMANA AI Backend",
    description=(
        "Dedicated Python AI and Analytical Backend for MoSPI PAIMANA Infrastructure Project Monitoring. "
        "Operates independently from the God's Eye 3D spatial client."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# CORS configuration (allowing local development access)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register route modules
app.include_router(health.router)
app.include_router(projects.router)
app.include_router(analytics.router)
app.include_router(future_ai.router)


@app.get("/", summary="API Root")
def root():
    """Root endpoint detailing API overview and documentation links."""
    return {
        "title": "SIH26103 PAIMANA AI Backend",
        "version": "1.0.0",
        "documentation": "/docs",
        "openapi_schema": "/openapi.json",
        "endpoints": {
            "health": "/health",
            "projects": "/projects",
            "project_detail": "/projects/{project_id}",
            "analytics_summary": "/analytics/summary",
            "data_quality": "/analytics/data-quality",
            "future_ai": "/ai/*",
        },
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
