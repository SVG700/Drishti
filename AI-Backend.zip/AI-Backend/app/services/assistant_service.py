"""Natural Language Project Inquiry Assistant Service for SIH26103 PAIMANA.

Grounds natural language questions in official MoSPI Flash Report records and the
backend's forecasting, delay-risk, anomaly, and executive report analytical services.
"""
from typing import Dict, Any, List, Optional, Tuple
import os
import re

from .data_loader import data_loader
from .forecast_service import forecast_service
from .delay_risk_service import delay_risk_service
from .anomaly_service import anomaly_service
from .report_service import report_service
from .analytics_service import analytics_service

COMMON_QUESTION_WORDS = {
    "what", "is", "the", "status", "of", "tell", "me", "about", "project", "show",
    "details", "for", "how", "much", "cost", "progress", "delay", "delayed", "risk",
    "anomaly", "anomalies", "report", "summary", "explain", "give", "any", "are",
    "there", "in", "on", "at", "please", "can", "you", "a", "an", "and", "or", "to",
    "when", "will", "why", "be", "been", "completed", "completion", "finish", "finished",
    "done", "work", "latest", "original", "revised", "spent", "expenditure", "brief"
}


class AssistantService:
    """Answers user inquiries regarding infrastructure projects grounded in PAIMANA data."""

    def __init__(self):
        self.llm_provider = os.environ.get("PAIMANA_LLM_PROVIDER")  # e.g., 'gemini', 'openai', or None
        self.gemini_api_key = os.environ.get("GEMINI_API_KEY")
        self.openai_api_key = os.environ.get("OPENAI_API_KEY")

    def resolve_project(self, query: str, project_id: Optional[str] = None) -> Tuple[str, Any]:
        """Resolves target project from explicit ID, embedded ID, or project title."""
        if not data_loader.is_loaded:
            data_loader.load_and_validate()

        # 1. Explicit project ID passed in request
        if project_id and str(project_id).strip():
            pid = str(project_id).strip()
            p = data_loader.projects_cache.get(pid)
            if p:
                return ("resolved", p)
            return ("id_not_found", pid)

        # 2. Check for 6-digit project ID embedded in query
        embedded_ids = re.findall(r"\b\d{6}\b", query)
        if embedded_ids:
            cand_id = embedded_ids[0]
            p = data_loader.projects_cache.get(cand_id)
            if p:
                return ("resolved", p)
            return ("id_not_found", cand_id)

        # 3. Check for general portfolio inquiry (not targeting a single project)
        q_lower = query.lower()
        if any(k in q_lower for k in [
            "how many projects", "total projects", "what is paimana", "all sectors",
            "portfolio overview", "dataset summary", "coverage period"
        ]):
            return ("general", None)

        # 4. Search by sliding-window n-grams (from 5 words down to 2)
        q_clean = re.sub(r"[^\w\s]", " ", query).lower()
        words = q_clean.split()

        for window_size in range(min(5, len(words)), 1, -1):
            for i in range(len(words) - window_size + 1):
                gram_words = words[i:i + window_size]
                if not any(w not in COMMON_QUESTION_WORDS for w in gram_words):
                    continue
                gram = " ".join(gram_words)
                if len(gram) >= 4:
                    cand = [
                        p for p in data_loader.projects_cache.values()
                        if gram in (p.get("project_name") or "").lower()
                    ]
                    if len(cand) == 1:
                        return ("resolved", cand[0])
                    elif len(cand) > 1:
                        return ("ambiguous", cand[:5])

        # 5. Single substantive word search fallback
        for w in words:
            if w not in COMMON_QUESTION_WORDS and len(w) >= 4:
                cand = [
                    p for p in data_loader.projects_cache.values()
                    if w in (p.get("project_name") or "").lower()
                ]
                if len(cand) == 1:
                    return ("resolved", cand[0])
                elif len(cand) > 1:
                    return ("ambiguous", cand[:5])

        # Substantive search phrase extraction for reporting not found
        substantive = [w for w in words if w not in COMMON_QUESTION_WORDS]
        unresolved_phrase = " ".join(substantive) if substantive else query.strip()
        return ("not_found", unresolved_phrase)

    def process_inquiry(
        self,
        query: str,
        project_id: Optional[str] = None,
        include_analytical_context: bool = True,
    ) -> Dict[str, Any]:
        """Processes a natural-language query and returns a structured, grounded answer."""
        if not data_loader.is_loaded:
            data_loader.load_and_validate()

        status, target = self.resolve_project(query, project_id)

        # Case A: Unknown Project ID
        if status == "id_not_found":
            return {
                "answer": (
                    f"Project ID '{target}' was not found in the official MoSPI PAIMANA repository "
                    f"(which monitors 2,100 Central Sector projects). Please verify the 6-digit project ID "
                    f"or search using official project title keywords."
                ),
                "project_id": target,
                "project_name": None,
                "latest_reported_month": None,
                "official_data_used": {},
                "analytical_results_used": {},
                "sources_used": ["data_loader.projects_cache"],
                "missing_or_unavailable_data": [f"project_id_{target}_not_found"],
                "clarification_options": None,
                "llm_synthesized": False,
                "disclaimer": "Official figures originate directly from MoSPI Flash Reports.",
            }

        # Case B: Ambiguous Project Name
        if status == "ambiguous":
            options = [
                {
                    "project_id": m.get("project_id"),
                    "project_name": m.get("project_name"),
                    "sector": m.get("sector"),
                    "agency": m.get("agency"),
                    "latest_reported_progress_pct": m.get("physical_progress_pct"),
                }
                for m in target
            ]
            opt_bullets = "\n".join(
                f"- **{o['project_id']}**: {o['project_name']} ({o['sector']} / {o['agency']})"
                for o in options
            )
            return {
                "answer": (
                    f"Your inquiry matches multiple projects in the PAIMANA database. "
                    f"Please clarify by specifying the project ID or exact title from the candidates below:\n\n"
                    f"{opt_bullets}"
                ),
                "project_id": None,
                "project_name": None,
                "latest_reported_month": None,
                "official_data_used": {},
                "analytical_results_used": {},
                "sources_used": ["data_loader.projects_cache"],
                "missing_or_unavailable_data": ["ambiguous_project_target"],
                "clarification_options": options,
                "llm_synthesized": False,
                "disclaimer": "Clarification requested to prevent selecting an unintended project record.",
            }

        # Case C: Search Phrase Not Found
        if status in ("not_found", "no_query_target"):
            phrase_str = f"'{target}'" if target else "your input"
            return {
                "answer": (
                    f"Could not identify a matching infrastructure project for {phrase_str} in the "
                    f"PAIMANA database. You can search by 6-digit project ID (e.g., 400102) or official "
                    f"project keyword (e.g., 'Hassan to Belur', 'Sri Ram Sagar')."
                ),
                "project_id": None,
                "project_name": None,
                "latest_reported_month": None,
                "official_data_used": {},
                "analytical_results_used": {},
                "sources_used": ["data_loader.projects_cache"],
                "missing_or_unavailable_data": ["project_search_unresolved"],
                "clarification_options": None,
                "llm_synthesized": False,
                "disclaimer": "Official figures originate directly from MoSPI Flash Reports.",
            }

        # Case D: General Portfolio Query
        if status == "general":
            summary = analytics_service.get_summary()
            ans = (
                f"The SIH26103 PAIMANA system currently monitors **{summary['total_projects']:,} Central Sector "
                f"Infrastructure Projects** based on official MoSPI Flash Reports covering July 2025 to March 2026. "
                f"Total cumulative original cost across the portfolio is ₹{summary['cumulative_original_cost_cr']:,.2f} Cr, "
                f"with cumulative expenditure of ₹{summary['cumulative_expenditure_cr']:,.2f} Cr. "
                f"Top monitored sectors include Railways, Road Transport & Highways, Petroleum, and Power."
            )
            return {
                "answer": ans,
                "project_id": None,
                "project_name": None,
                "latest_reported_month": "2026-03",
                "official_data_used": summary,
                "analytical_results_used": {},
                "sources_used": ["analytics_service.get_summary"],
                "missing_or_unavailable_data": [],
                "clarification_options": None,
                "llm_synthesized": False,
                "disclaimer": "Portfolio aggregate figures derived from official MoSPI Flash Reports.",
            }

        # Case E: Single Project Resolved
        p = target
        pid = p.get("project_id")
        p_name = p.get("project_name")
        sector = p.get("sector")
        agency = p.get("agency")
        state = p.get("state")
        orig_cost = p.get("original_cost_cr")
        rev_cost = p.get("revised_cost_cr")
        cum_exp = p.get("cumulative_expenditure_cr")
        phys_prog = p.get("physical_progress_pct")
        cost_overrun = p.get("cost_overrun_cr")
        cost_overrun_pct = p.get("cost_overrun_pct")
        time_overrun = p.get("time_overrun_months")
        orig_doc = p.get("original_doc")
        rev_doc = p.get("revised_doc")
        derived_status = p.get("derived_status") or "In Progress"
        latest_month = str(p.get("report_month_key") or "2026-03")

        missing_fields = []
        if orig_cost is None:
            missing_fields.append("original_cost_cr")
        if rev_cost is None:
            missing_fields.append("revised_cost_cr")
        if cum_exp is None:
            missing_fields.append("cumulative_expenditure_cr")
        if phys_prog is None:
            missing_fields.append("physical_progress_pct")
        if orig_doc is None:
            missing_fields.append("original_doc")
        if rev_doc is None:
            missing_fields.append("revised_doc")

        official_data = {
            "project_id": pid,
            "project_name": p_name,
            "sector": sector,
            "agency": agency,
            "state": state,
            "original_cost_cr": orig_cost,
            "revised_cost_cr": rev_cost,
            "cost_overrun_cr": cost_overrun,
            "cost_overrun_pct": cost_overrun_pct,
            "cumulative_expenditure_cr": cum_exp,
            "physical_progress_pct": phys_prog,
            "derived_status": derived_status,
            "official_time_overrun_months": time_overrun,
            "original_doc": orig_doc,
            "revised_doc": rev_doc,
            "latest_reported_month": latest_month,
        }

        # Intent Detection
        q_lower = query.lower()

        is_corruption_query = any(k in q_lower for k in [
            "corrupt", "fraud", "scam", "embezzle", "stole", "kickback", "guilty", "why was contractor", "court"
        ])
        is_forecast_query = any(k in q_lower for k in [
            "forecast", "predict", "when will", "completion date", "finish", "completion doc", "trajectory", "horizon"
        ])
        is_delay_query = any(k in q_lower for k in [
            "delay", "delayed", "late", "behind schedule", "stagnat", "slippage", "overrun", "schedule risk"
        ])
        is_anomaly_query = any(k in q_lower for k in [
            "anomaly", "anomalies", "decoupling", "surge", "outlier", "irregular", "budget exhaustion", "breach"
        ])
        is_cost_query = any(k in q_lower for k in [
            "cost", "budget", "expenditure", "spend", "spent", "financial", "crore", "cr", "fund", "money"
        ])
        is_progress_query = any(k in q_lower for k in [
            "progress", "physical", "completed", "completion", "how much work"
        ])
        is_report_query = any(k in q_lower for k in [
            "report", "executive report", "brief", "intelligence report", "summary of project"
        ])

        sources_used = ["MoSPI PAIMANA Project Snapshot"]
        analytical_results: Dict[str, Any] = {}

        # -------------------------------------------------------------
        # Unanswerable qualitative / legal inquiries
        # -------------------------------------------------------------
        if is_corruption_query:
            answer = (
                f"Regarding Project {pid} ('{p_name}'): Official MoSPI PAIMANA Flash Reports track "
                f"monthly quantitative engineering and financial parameters (cumulative expenditure, physical "
                f"milestone percentage, and commissioning dates). MoSPI reports **do not contain** legal proceedings, "
                f"contractor litigation, or determinations of fraud/misconduct. Any anomaly signals flagged by PAIMANA "
                f"are statistical prompts for on-site administrative reconciliation and physical verification, "
                f"not evidence of wrongdoing."
            )
            return {
                "answer": answer,
                "project_id": pid,
                "project_name": p_name,
                "latest_reported_month": latest_month,
                "official_data_used": official_data,
                "analytical_results_used": {},
                "sources_used": sources_used,
                "missing_or_unavailable_data": ["legal_and_contractor_adjudication_records_not_in_mospi"],
                "clarification_options": None,
                "llm_synthesized": False,
                "disclaimer": "Official MoSPI Flash Reports do not record legal or administrative misconduct findings.",
            }

        # -------------------------------------------------------------
        # Fetch analytical context if needed
        # -------------------------------------------------------------
        f_res = None
        d_res = None
        a_res = None
        r_res = None

        if include_analytical_context:
            if is_report_query:
                try:
                    r_res = report_service.generate_report(pid)
                    sources_used.append("Executive Report Synthesis Service")
                except Exception:
                    r_res = None

            if is_forecast_query or is_report_query or is_delay_query:
                try:
                    f_res = forecast_service.get_project_forecast(pid, horizon_months=6)
                    sources_used.append("Adaptive Velocity Forecast Service")
                except Exception:
                    f_res = None

            if is_delay_query or is_report_query:
                try:
                    d_res = delay_risk_service.evaluate_delay_risk(pid)
                    sources_used.append("Delay Risk & Stagnation Service")
                except Exception:
                    d_res = None

            if is_anomaly_query or is_report_query or is_cost_query:
                try:
                    a_res = anomaly_service.evaluate_anomalies(pid)
                    sources_used.append("Expenditure & Anomaly Detection Service")
                except Exception:
                    a_res = None

        # Build analytical payload
        if f_res:
            analytical_results["forecast"] = {
                "forecasted_completion_doc": f_res.get("forecasted_completion_doc"),
                "estimated_monthly_velocity_pct": f_res.get("model_metadata", {}).get("estimated_monthly_velocity_pct"),
                "projected_slippage_months": f_res.get("projected_slippage_months"),
                "data_sufficiency": f_res.get("data_sufficiency"),
            }
        if d_res:
            analytical_results["delay_risk"] = {
                "risk_level": d_res.get("risk_level"),
                "risk_score": d_res.get("risk_score"),
                "triggered_indicators": [i["indicator_code"] for i in d_res.get("risk_indicators", []) if i.get("triggered")],
            }
        if a_res:
            analytical_results["anomalies"] = {
                "anomaly_status": a_res.get("anomaly_status"),
                "composite_anomaly_score": a_res.get("composite_anomaly_score"),
                "triggered_indicators": [i["indicator_code"] for i in a_res.get("indicators", []) if i.get("triggered")],
            }
        if r_res:
            analytical_results["executive_summary"] = {
                "overall_health": r_res.get("executive_summary", {}).get("overall_health"),
                "primary_risks": r_res.get("executive_summary", {}).get("primary_risks", []),
            }

        # -------------------------------------------------------------
        # Formulate Deterministic Grounded Answer
        # -------------------------------------------------------------
        parts: List[str] = []

        # Executive Report Summary
        if is_report_query and r_res:
            es = r_res.get("executive_summary", {})
            parts.append(f"**Executive Intelligence Brief for Project {pid} — {p_name}**:")
            parts.append(f"Overall Health: **{es.get('overall_health')}**.")
            parts.append(es.get("summary_text", ""))
            if es.get("key_findings"):
                parts.append("\n**Key Findings**:\n" + "\n".join(f"- {f}" for f in es["key_findings"]))
            if es.get("primary_risks") and "No critical" not in es["primary_risks"][0]:
                parts.append("\n**Primary Risks**:\n" + "\n".join(f"- {r}" for r in es["primary_risks"][:3]))

        # Progress Forecast Focus
        elif is_forecast_query:
            parts.append(f"**Progress Forecast for Project {pid} ('{p_name}')**: ")
            if phys_prog is not None:
                parts.append(f"Latest reported physical progress is **{phys_prog:.1f}%** as of {latest_month} (Status: {derived_status}).")
            else:
                parts.append(f"Latest physical progress percentage is missing from available MoSPI reports.")

            if f_res:
                f_doc = f_res.get("forecasted_completion_doc")
                f_vel = f_res.get("model_metadata", {}).get("estimated_monthly_velocity_pct")
                f_slip = f_res.get("projected_slippage_months")
                f_suff = f_res.get("data_sufficiency")

                if derived_status == "Completed" or (phys_prog and phys_prog >= 100.0):
                    parts.append("The project is already 100% completed / commissioned.")
                elif f_vel is not None and f_vel > 0:
                    parts.append(
                        f"Based on historical run-rate velocity ({f_vel:.2f}%/month), the predictive model projects "
                        f"completion by **{f_doc}**."
                    )
                    if f_slip is not None and f_slip > 0:
                        parts.append(f"This indicates a projected schedule slippage of **+{f_slip:.1f} months** beyond the target date.")
                    elif rev_doc:
                        parts.append(f"This aligns with the official target commissioning date of {rev_doc}.")
                else:
                    parts.append("Progress velocity is near zero or stalled; model extrapolation indicates an extended completion horizon.")

                if f_suff != "sufficient":
                    parts.append(f"*(Note: Observation history depth is {f_suff}; projection incorporates sector baseline velocity.)*")
            else:
                parts.append("Progress forecasting model could not be computed due to insufficient historical observations.")

        # Delay Risk Focus
        elif is_delay_query:
            parts.append(f"**Schedule & Delay Risk for Project {pid} ('{p_name}')**: ")
            if time_overrun is not None and time_overrun > 0:
                parts.append(f"Official MoSPI reports document an accumulated schedule time overrun of **{time_overrun:.1f} months** (Status: {derived_status}).")
            else:
                parts.append(f"Official MoSPI reports indicate **zero schedule delay** (Status: {derived_status}).")

            if orig_doc:
                parts.append(f"Original Date of Commissioning (DOC) was **{orig_doc}**")
            if rev_doc:
                parts.append(f"and revised target DOC is **{rev_doc}**.")

            if d_res:
                r_level = d_res.get("risk_level")
                r_score = d_res.get("risk_score")
                parts.append(f"Our analytical delay-risk model evaluates this project at **'{r_level}'** risk (score: {r_score:.2f}).")
                trig = [i["name"] for i in d_res.get("risk_indicators", []) if i.get("triggered")]
                if trig:
                    parts.append(f"Active risk drivers: {', '.join(trig)}.")
                else:
                    parts.append("No active schedule stagnation or milestone overrun drivers detected.")

        # Anomaly & Decoupling Focus
        elif is_anomaly_query:
            parts.append(f"**Expenditure & Progress Anomaly Evaluation for Project {pid} ('{p_name}')**: ")
            if a_res:
                a_stat = a_res.get("anomaly_status")
                a_score = a_res.get("composite_anomaly_score")
                parts.append(f"Project anomaly status is classified as **'{a_stat}'** (composite score: {a_score:.2f}).")
                trig_inds = [i for i in a_res.get("indicators", []) if i.get("triggered")]
                if trig_inds:
                    parts.append("Detected statistical signals:")
                    for ind in trig_inds:
                        parts.append(f"- **{ind['name']}**: {ind['description']}")
                else:
                    parts.append("No statistical expenditure decoupling, budget exhaustion, or cost overrun anomalies were detected.")

                if a_res.get("monthly_anomalies"):
                    parts.append(f"Recorded {len(a_res['monthly_anomalies'])} specific month-over-month anomalous transition(s).")
            else:
                parts.append("Anomaly detection could not be computed due to missing budget or expenditure records.")

        # Cost & Expenditure Focus
        elif is_cost_query:
            parts.append(f"**Financial Overview for Project {pid} ('{p_name}')**: ")
            if orig_cost is not None:
                parts.append(f"Original sanctioned cost: **₹{orig_cost:.2f} Cr**.")
            else:
                parts.append("Original sanctioned cost is unrecorded.")

            if rev_cost is not None:
                parts.append(f"Revised cost ceiling: **₹{rev_cost:.2f} Cr**.")
            else:
                parts.append("Revised cost is unrecorded.")

            if cost_overrun is not None and cost_overrun > 0:
                parts.append(f"Official administrative cost overrun is **+₹{cost_overrun:.2f} Cr (+{cost_overrun_pct:.1f}%)**.")

            if cum_exp is not None:
                parts.append(f"Cumulative expenditure to date is **₹{cum_exp:.2f} Cr** as of {latest_month}.")
                effective_cost = rev_cost or orig_cost
                if effective_cost and effective_cost > 0:
                    fin_pct = (cum_exp / effective_cost) * 100.0
                    parts.append(f"Financial progress stands at **{fin_pct:.1f}%**.")
            else:
                parts.append("Cumulative expenditure is unrecorded.")

            if a_res and "EXPENDITURE_BUDGET_BREACH" in [i["indicator_code"] for i in a_res.get("indicators", []) if i.get("triggered")]:
                parts.append("⚠️ **Notice**: Cumulative expenditure has breached the authorized revised cost ceiling.")

        # Progress Focus
        elif is_progress_query:
            parts.append(f"**Physical Progress for Project {pid} ('{p_name}')**: ")
            if phys_prog is not None:
                parts.append(f"Physical milestone execution is at **{phys_prog:.1f}%** as of {latest_month} (Status: {derived_status}).")
            else:
                parts.append("Physical progress percentage is not recorded in the latest PAIMANA report.")

            if f_res and f_res.get("model_metadata"):
                vel = f_res["model_metadata"].get("estimated_monthly_velocity_pct")
                if vel is not None:
                    parts.append(f"Current estimated monthly execution velocity is **{vel:.2f}%/month**.")

        # General Overview / Comprehensive Summary
        else:
            parts.append(f"**Project Summary for {pid} — {p_name}**:")
            parts.append(f"Sector: **{sector}** | Implementing Agency: **{agency}** | State: **{state or 'Not Specified'}**.")
            
            # Progress & Status
            if phys_prog is not None:
                parts.append(f"Physical execution stands at **{phys_prog:.1f}%** (Status: **{derived_status}** as of {latest_month}).")
            else:
                parts.append(f"Status is **{derived_status}** as of {latest_month} (physical progress unrecorded).")

            # Financials
            if cum_exp is not None:
                parts.append(f"Expenditure stands at **₹{cum_exp:.2f} Cr**")
                if rev_cost is not None:
                    parts.append(f"against a revised budget of **₹{rev_cost:.2f} Cr**.")
                elif orig_cost is not None:
                    parts.append(f"against an original budget of **₹{orig_cost:.2f} Cr**.")
                else:
                    parts.append("(sanctioned budget unrecorded).")

            # Schedule & Overrun
            if time_overrun is not None and time_overrun > 0:
                parts.append(f"Accumulated schedule delay: **{time_overrun:.1f} months**.")
            elif rev_doc:
                parts.append(f"Scheduled target completion: **{rev_doc}**.")

            # Analytical Highlights
            if d_res:
                parts.append(f"Delay risk level: **{d_res.get('risk_level')}**.")
            if a_res:
                parts.append(f"Anomaly status: **{a_res.get('anomaly_status')}**.")

        final_answer = " ".join(parts)

        # -------------------------------------------------------------
        # Optional External LLM Integration
        # -------------------------------------------------------------
        llm_used = False
        if self.llm_provider:
            try:
                # LLM can be invoked via configured client here
                # Treat retrieved facts as structured context
                llm_used = self._call_external_llm(query, final_answer, official_data, analytical_results)
                if not llm_used:
                    llm_used = False
            except Exception:
                llm_used = False

        return {
            "answer": final_answer,
            "project_id": pid,
            "project_name": p_name,
            "latest_reported_month": latest_month,
            "official_data_used": official_data,
            "analytical_results_used": analytical_results,
            "sources_used": sources_used,
            "missing_or_unavailable_data": missing_fields,
            "clarification_options": None,
            "llm_synthesized": llm_used,
            "disclaimer": (
                "Official figures originate directly from MoSPI Flash Reports. Projections, delay risk scores, "
                "and anomaly alerts are statistical heuristics and do not represent official government determinations."
            ),
        }

    def _call_external_llm(
        self,
        query: str,
        base_answer: str,
        official_data: Dict[str, Any],
        analytical_results: Dict[str, Any],
    ) -> bool:
        """Hook for external LLM provider synthesis if configured."""
        # Configurable via PAIMANA_LLM_PROVIDER
        # Default behavior: returns False to use deterministic verified answer
        return False


assistant_service = AssistantService()
