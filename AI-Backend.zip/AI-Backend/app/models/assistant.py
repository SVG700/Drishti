"""Pydantic schemas for the Natural Language Project Inquiry Assistant."""
from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field


class AssistantClarificationOption(BaseModel):
    """Candidate project option returned when a query resolves ambiguously."""
    project_id: str
    project_name: Optional[str] = None
    sector: Optional[str] = None
    agency: Optional[str] = None
    latest_reported_progress_pct: Optional[float] = None


class AIAssistantRequest(BaseModel):
    """User query or prompt to the PAIMANA AI assistant."""
    query: str = Field(..., min_length=1, description="Natural language question regarding PAIMANA infrastructure projects")
    project_id: Optional[str] = Field(None, description="Optional target project ID (6-digit MoSPI ID)")
    include_analytical_context: bool = Field(True, description="Whether to compute forecast, delay-risk, and anomaly context")


class AIAssistantResponse(BaseModel):
    """AI assistant answer strictly grounded on MoSPI project data and analytical modules."""
    answer: str = Field(..., description="Assistant response text grounded in retrieved facts")
    project_id: Optional[str] = Field(None, description="Identified project ID if grounded on a specific project")
    project_name: Optional[str] = Field(None, description="Identified project name")
    latest_reported_month: Optional[str] = Field(None, description="Latest MoSPI report month referenced (YYYY-MM)")
    official_data_used: Dict[str, Any] = Field(default_factory=dict, description="Verified official MoSPI figures referenced")
    analytical_results_used: Dict[str, Any] = Field(default_factory=dict, description="Model-generated forecast, delay risk, or anomaly findings used")
    sources_used: List[str] = Field(default_factory=list, description="Data sources and analytical modules queried")
    missing_or_unavailable_data: List[str] = Field(default_factory=list, description="Relevant metrics missing from official reports")
    clarification_options: Optional[List[AssistantClarificationOption]] = Field(None, description="Candidate projects if query was ambiguous")
    llm_synthesized: bool = Field(default=False, description="Whether an external LLM was used to generate response phrasing")
    disclaimer: str = Field(
        default="Official figures originate directly from MoSPI Flash Reports. Projections, delay risk scores, and anomaly alerts are statistical heuristics and do not represent official government determinations."
    )
