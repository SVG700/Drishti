"""Utility and validation scripts."""
