"""Automated unit and integration tests for Natural Language Project Inquiry Assistant."""
import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient

from app.main import app
from app.services.assistant_service import assistant_service
from app.models.assistant import AIAssistantResponse


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def test_assistant_known_project_id_query():
    """Verify that a question with a valid 6-digit project ID is correctly identified and answered."""
    result = assistant_service.process_inquiry("Tell me about project 400102")
    assert result["project_id"] == "400102"
    assert result["project_name"] == "Sri Ram Sagar Project Stage - II"
    assert "Water Resources" in result["answer"]
    assert len(result["sources_used"]) > 0
    assert result["clarification_options"] is None

    # Validate against Pydantic schema
    response_obj = AIAssistantResponse(**result)
    assert response_obj.project_id == "400102"


def test_assistant_project_id_in_request_param():
    """Verify that passing project_id as an explicit request argument overrides query parsing."""
    result = assistant_service.process_inquiry("What is the cost?", project_id="400023")
    assert result["project_id"] == "400023"
    assert "Hassan to Belur" in result["project_name"]
    assert "₹749.00 Cr" in result["answer"]
    assert result["official_data_used"]["original_cost_cr"] == 749.0


def test_assistant_project_name_resolution():
    """Verify that querying by project name resolves to the correct single project."""
    result = assistant_service.process_inquiry("When will Hassan to Belur be completed?")
    assert result["project_id"] == "400023"
    assert "Hassan to Belur" in result["project_name"]
    assert "Progress Forecast" in result["answer"]
    assert "forecast" in result["analytical_results_used"]


def test_assistant_ambiguous_project_name():
    """Verify that ambiguous queries matching multiple projects return clarification options rather than guessing."""
    result = assistant_service.process_inquiry("Tell me about Metro Rail")
    assert result["project_id"] is None
    assert result["clarification_options"] is not None
    assert len(result["clarification_options"]) > 1
    assert "ambiguous_project_target" in result["missing_or_unavailable_data"]
    assert "clarify by specifying" in result["answer"].lower()

    # Candidates should have valid project metadata
    first_option = result["clarification_options"][0]
    assert "project_id" in first_option
    assert "project_name" in first_option


def test_assistant_unknown_project_id():
    """Verify that unknown project IDs return a helpful not-found message."""
    result = assistant_service.process_inquiry("What is the status of project 999999?")
    assert result["project_id"] == "999999"
    assert result["project_name"] is None
    assert "not found" in result["answer"].lower()
    assert "project_id_999999_not_found" in result["missing_or_unavailable_data"]


def test_assistant_missing_financial_data_preservation():
    """Verify that missing budget baseline data is acknowledged as unavailable rather than inventing 0."""
    result = assistant_service.process_inquiry("What is the cost of project 602797?")
    assert result["project_id"] == "602797"
    assert "original_cost_cr" in result["missing_or_unavailable_data"]
    assert "unrecorded" in result["answer"].lower()


def test_assistant_forecast_inquiry():
    """Verify analytical grounding for project progress forecasting and completion target dates."""
    result = assistant_service.process_inquiry("What is the projected completion date for 400102?")
    assert result["project_id"] == "400102"
    assert "Progress Forecast" in result["answer"]
    assert "forecast" in result["analytical_results_used"]
    assert result["analytical_results_used"]["forecast"]["forecasted_completion_doc"] is not None
    assert "Adaptive Velocity Forecast Service" in result["sources_used"]


def test_assistant_delay_risk_inquiry():
    """Verify analytical grounding for schedule delays, official overruns, and risk levels."""
    result = assistant_service.process_inquiry("Is project 400010 delayed?")
    assert result["project_id"] == "400010"
    assert "Schedule & Delay Risk" in result["answer"]
    assert "58.0 months" in result["answer"] or "overrun" in result["answer"].lower()
    assert "delay_risk" in result["analytical_results_used"]
    assert result["analytical_results_used"]["delay_risk"]["risk_level"] in ("Critical", "High")


def test_assistant_anomaly_inquiry():
    """Verify analytical grounding for expenditure-progress decoupling and budget exhaustion anomalies."""
    result = assistant_service.process_inquiry("Are there any anomalies in 611752?")
    assert result["project_id"] == "611752"
    assert "Expenditure & Progress Anomaly Evaluation" in result["answer"]
    assert "anomalies" in result["analytical_results_used"]
    assert result["analytical_results_used"]["anomalies"]["anomaly_status"] in ("Critical", "Warning")
    assert "Expenditure & Anomaly Detection Service" in result["sources_used"]


def test_assistant_executive_report_inquiry():
    """Verify synthesis of high-level executive report briefs."""
    result = assistant_service.process_inquiry("Give me an executive report brief for 400102")
    assert result["project_id"] == "400102"
    assert "Executive Intelligence Brief" in result["answer"]
    assert "Overall Health" in result["answer"]


def test_assistant_unanswerable_qualitative_inquiry():
    """Verify that unrecorded legal/misconduct inquiries are addressed with transparent boundary disclaimers."""
    result = assistant_service.process_inquiry("Was there fraud or corruption in project 400102?")
    assert result["project_id"] == "400102"
    assert "legal_and_contractor_adjudication_records_not_in_mospi" in result["missing_or_unavailable_data"]
    assert "do not contain" in result["answer"].lower()
    assert "misconduct" in result["answer"].lower()


def test_assistant_general_portfolio_inquiry():
    """Verify portfolio-level statistical answers when no single project is targeted."""
    result = assistant_service.process_inquiry("How many projects are monitored in PAIMANA?")
    assert result["project_id"] is None
    assert "2,100" in result["answer"]
    assert "analytics_service.get_summary" in result["sources_used"]


def test_assistant_mock_llm_failure_graceful_fallback():
    """Verify that if an external LLM fails, the assistant gracefully falls back to deterministic grounded output."""
    with patch.object(assistant_service, "_call_external_llm", side_effect=RuntimeError("LLM Provider Timeout")):
        result = assistant_service.process_inquiry("Tell me about 400023")
        assert result is not None
        assert result["project_id"] == "400023"
        assert result["llm_synthesized"] is False
        assert "Hassan to Belur" in result["answer"]


def test_assistant_api_endpoint_success(client):
    """Verify POST /ai/assistant returns HTTP 200 with valid AIAssistantResponse schema."""
    response = client.post("/ai/assistant", json={"query": "Tell me about project 400023"})
    assert response.status_code == 200
    data = response.json()
    assert data["project_id"] == "400023"
    assert "answer" in data
    assert "official_data_used" in data
    assert "sources_used" in data
    assert "disclaimer" in data


def test_assistant_api_validation_error(client):
    """Verify POST /ai/assistant rejects empty query with HTTP 422 Unprocessable Entity."""
    response = client.post("/ai/assistant", json={"query": ""})
    assert response.status_code == 422
